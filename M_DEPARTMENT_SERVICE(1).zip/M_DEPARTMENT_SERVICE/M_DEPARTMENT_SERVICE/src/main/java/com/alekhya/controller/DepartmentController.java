package com.alekhya.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alekhya.entities.DepartmentEntity;
import com.alekhya.service.DepartmentService;

@RestController
@RequestMapping("/department")
@CrossOrigin
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;

	@GetMapping("/byid/{deptId}")
	public DepartmentEntity getDepartment(@PathVariable Integer deptId) {
		return departmentService.getOne(deptId);
	}
	
	@GetMapping
	public List<DepartmentEntity> getAll(){
		return departmentService.getAll();
	}
	
	@PostMapping   //http://172.19.5.25:2222/department
	public DepartmentEntity create(@RequestBody DepartmentEntity departmentEntity) {
		return departmentService.create(departmentEntity);
	}

}
