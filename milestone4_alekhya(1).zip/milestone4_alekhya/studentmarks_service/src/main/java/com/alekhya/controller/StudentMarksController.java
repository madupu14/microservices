package com.alekhya.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.alekhya.entity.StudentMarks;
import com.alekhya.repository.StudentMarksRepository;

@RestController
@RequestMapping("/studentMarks")
public class StudentMarksController {

    @Autowired
    private StudentMarksRepository studentMarksRepository;

    @GetMapping("/{id}")
    public StudentMarks getStudentMarksById(@PathVariable Long id) {
        return studentMarksRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student marks not found with id: " + id));
    }

    @PostMapping
    public StudentMarks createStudentMarks(@RequestBody StudentMarks studentMarks) {
        return studentMarksRepository.save(studentMarks);
    }


}
