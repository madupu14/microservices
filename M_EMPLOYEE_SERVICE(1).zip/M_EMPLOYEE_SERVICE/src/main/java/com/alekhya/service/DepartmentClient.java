package com.alekhya.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.alekhya.vo.DepartmentVO;


@FeignClient(name="ALU-DEPARTMENT-SERVICE")
public interface DepartmentClient {

	@GetMapping("/department/byid/{deptId}")
	public DepartmentVO getDepartment(@PathVariable Integer deptId); 
	
}
