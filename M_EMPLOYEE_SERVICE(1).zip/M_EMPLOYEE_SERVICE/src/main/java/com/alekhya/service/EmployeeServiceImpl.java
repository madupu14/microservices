package com.alekhya.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alekhya.entity.EmployeeEntity;
import com.alekhya.repository.EmployeeRepository;
import com.alekhya.vo.DepartmentVO;
import com.alekhya.vo.EmployeeDepartmentVO;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private DepartmentClient departmentClient;
	
	@Override
	public EmployeeEntity createEmployee(EmployeeEntity employeeEntity) {
		
		return employeeRepository.save(employeeEntity);

	}

	@Override
	public List<EmployeeEntity> getAll() {
		return employeeRepository.findAll();
	}

	@Override
	public EmployeeEntity getOne(Integer empId) {
		Optional<EmployeeEntity> optional= employeeRepository.findById(empId);
		if(optional.isPresent()){
			return optional.get();
		}else {
			return null;
		}
	}
	
	@Override
	public EmployeeDepartmentVO getEmployeeWithDepartmentInfo(Integer empId) {
//		Optional<EmployeeEntity> optional= employeeRepository.findById(empId);
//		if(optional.isPresent()) {
//			EmployeeEntity employeeEntity =	optional.get();
//			Integer deptId = employeeEntity.getDeptId();
//			String urlGET = "http://localhost:2222/department/byid/"+deptId;   // endpoint
//			//HttpClient //RestClient //RestTemplate //WebClient // Spring- Feign Client
//			RestTemplate restTemplate = new RestTemplate();
//			DepartmentVO departmentVO = restTemplate.getForObject(urlGET, DepartmentVO.class);
//			EmployeeDepartmentVO edVO = new EmployeeDepartmentVO();
//			edVO.setEmployeeEntity(employeeEntity);
//			edVO.setDepartmentVO(departmentVO);
//			
//			return edVO;
//		}
		return null;
	}
	
	
	@Override
	public EmployeeDepartmentVO getEmployeeWithDepartmentInfoWithFeign(Integer empId) {
		Optional<EmployeeEntity> optional= employeeRepository.findById(empId);
		if(optional.isPresent()) {
			EmployeeEntity employeeEntity =	optional.get();
			Integer deptId = employeeEntity.getDeptId();
			DepartmentVO departmentVO = departmentClient.getDepartment(deptId);
			EmployeeDepartmentVO edVO = new EmployeeDepartmentVO();
			edVO.setEmployeeEntity(employeeEntity);
			edVO.setDepartmentVO(departmentVO);
			return edVO; 
		}
		return null;
	}

	@Override
	public List<EmployeeEntity> getByDeptId(Integer deptId) {
		return employeeRepository.findByDeptId(deptId);
	}

//	@Override
//	public EmployeeDepartmentVO getEmployeeWithDepartmentInfo(Integer empId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public EmployeeDepartmentVO getEmployeeWithDepartmentInfoWithFeign(Integer empId) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
