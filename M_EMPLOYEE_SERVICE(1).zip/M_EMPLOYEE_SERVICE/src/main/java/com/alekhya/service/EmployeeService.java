package com.alekhya.service;

import java.util.List;

import com.alekhya.entity.EmployeeEntity;
import com.alekhya.vo.EmployeeDepartmentVO;

public interface EmployeeService {
		

	public EmployeeEntity createEmployee(EmployeeEntity employeeEntity);
	public List<EmployeeEntity> getAll();
	public EmployeeEntity getOne(Integer empId);
	public List<EmployeeEntity> getByDeptId(Integer deptId); 
	public EmployeeDepartmentVO getEmployeeWithDepartmentInfo(Integer empId);
	EmployeeDepartmentVO getEmployeeWithDepartmentInfoWithFeign(Integer empId);
}
