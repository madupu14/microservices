package com.alekhya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MDepartmentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MDepartmentServiceApplication.class, args);
	}

}
